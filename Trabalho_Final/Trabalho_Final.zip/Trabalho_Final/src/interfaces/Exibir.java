package interfaces;

public interface Exibir {
	
    void exibirDetalhes();
}
