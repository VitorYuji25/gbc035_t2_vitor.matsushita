package enum_entites;

public enum Tipo_Embalagem {
	
	LATA,
	GARRAFA_PLASTICA,
	GARRAFA_VIDRO,
	OUTRO_TIPO
}
