package enum_entites;

public enum Categoria {

	PRATO_PRINCIPAL,
	BEBIDA, 
	SOBREMESA
}
