package enum_entites;

public enum Tipo_Pagamento {

	DEBITO,
	CREDITO,
	DINHEIRO,
	OUTRO_TIPO
}
